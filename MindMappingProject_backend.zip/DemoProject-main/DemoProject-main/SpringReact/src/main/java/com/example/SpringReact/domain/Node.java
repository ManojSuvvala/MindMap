package com.example.SpringReact.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import org.hibernate.annotations.Type;
//Lombok
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "nodes")
public class Node {
    @Id
    private String id;
    private String type;
    private String label;
    private double x;
    private double y;
    private String edge_id;
    private String edge_source;
    private String edge_target;
 /*   @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "label", column = @Column(name = "label"))
    })
    @Type(type = "jsonb") // Specify the type mapping for the data field
    private Data data = new Data();*/

 /*   @Embedded
    private Position position = new Position();
*/
    private String dragHandle;
    private String parentNode;

    // Getters and setters

/*    @Embeddable
    public static class Data {
        private String label;

        // Getters and setters
    }

    @Embeddable
    public static class Position {
        private double x;
        private double y;

        // Getters and setters
    }*/

}
