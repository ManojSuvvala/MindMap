package com.example.SpringReact.service;

import com.example.SpringReact.domain.Account;
import com.example.SpringReact.domain.Login;
import com.example.SpringReact.domain.User;
import com.example.SpringReact.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    @Transactional
    public Account create(Account account){
        return accountRepository.save(account);
    }
}
