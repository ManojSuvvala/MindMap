package com.example.SpringReact.controller;

import com.example.SpringReact.domain.Node;
import com.example.SpringReact.service.NodeService;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.RequiredArgsConstructor;
import org.apache.tomcat.util.json.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
//import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@RestController
public class NodeController {


    private final NodeService nodeService;
    /*
    @GetMapping("/")
    public ResponseEntity<?> findAll(){
        return new ResponseEntity<String>("ok", HttpStatus.OK);
    }
    */

    /* ResponseEntity
    ResponseEntity represents the whole HTTP response: status code, headers, and body.
    As a result, we can use it to fully configure the HTTP response.
    */

    /* @RequestBody
    Annotation indicating a method parameter should be bound to the body of the web request.
    */

    /* @RequestBody
    @PathVariable annotation can be used to handle template variables in the request URI mapping
    */

    @CrossOrigin
    @PostMapping("/save-node")
    public ResponseEntity<?> save(@RequestBody String json){
        Node node1 = new Node();
//        node1.setId(node.getId());
//        node1.setParentNode(node.getParentNode());
        //node1.setPositionX();
/*        Node newNode = new Node();
        newNode.setId(node.getId());
        newNode.setType(node.getType());
        newNode.setData(node.getData());
        newNode.setPosition(node.getPosition());
        newNode.setDragHandle(node.getDragHandle());
        newNode.setParentNode(node.getParentNode());
        System.out.println("title " + node.getData());
        System.out.println("author " + node.getData());
        System.out.println(node.getData());*/

//        json.fields().forEachRemaining(entry -> {
//            String key = entry.getKey();
//            JsonNode value = entry.getValue();
//            if (value.isObject()) {
//               // processJsonObject(value); // Recursively process nested JSON objects
//                System.out.println("Keyy: " + key + ", Value: " + value);
//            } else {
//                // Store the key-value pair (e.g., in a database, list, or map)
//                System.out.println("Key: " + key + ", Value: " + value);
//            }
//        });
        String jsonString = "[{\"id\":\"root\",\"type\":\"mindmap\",\"data\":{\"label\":\"React Flow Mind Map\"},\"position\":{\"x\":0,\"y\":0},\"dragHandle\":\".dragHandle\",\"width\":194,\"height\":69},{\"id\":\"c_Ulo6tE_WpYoSdD0qRWq\",\"type\":\"mindmap\",\"data\":{\"label\":\"New Node\"},\"position\":{\"x\":-42,\"y\":23.5},\"dragHandle\":\".dragHandle\",\"parentNode\":\"root\"}]";


        try {
            //JSONParser parser = new JSONParser(json);
            JSONParser parser = new JSONParser(json);
            Object obj_  = parser.parse();
            JSONArray jsonArray = new JSONArray();
            jsonArray.add(obj_);
            //JSONArray jsonArray = (JSONArray) JSONValue.parse(json);
            //jsonArray.add(json);
            //int i = 0;
            for (Object obj : jsonArray) {

                LinkedHashMap<String, Object> linkedHashMap = (LinkedHashMap<String, Object>) obj;
// Populate the linkedHashMap with data

                JSONObject jsonObject1 = new JSONObject(linkedHashMap);
                ArrayList<String> arrayList = new ArrayList<>();

// Populate the arrayList with data

                JSONObject jsonObject2 = new JSONObject();
                jsonObject2.put("edges", jsonObject1.get("edges"));
                jsonObject2.put("nodes", jsonObject1.get("nodes"));
                //JSONObject jsonObject = (JSONObject) obj;
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("edges", jsonObject2.get("edges"));
                jsonObject.put("nodes", jsonObject2.get("nodes"));
                ArrayList<Object> arr_nodes = (ArrayList<Object>) jsonObject.get("nodes");
                ArrayList<Object> arr_edges = (ArrayList<Object>) jsonObject.get("edges");
                boolean temp = false;
                for(int i=0;i<arr_nodes.size();i++) {
                    Node node_obj = new Node();
                    temp = false;
                    if (arr_edges.size()-1 >= i)
                    {
                        temp = true;
                    }
                    JSONObject nodes = new JSONObject((Map) arr_nodes.get(i));
                    JSONObject edges = new JSONObject((Map) arr_edges.get(0));
                    if(temp) {
                         edges = new JSONObject((Map) arr_edges.get(i));
                    }
                    String id = (String) nodes.get("id");
                    String edge_id = null;
                    String edge_source = null;
                    String edge_target = null;
                    if(temp) {
                         edge_id = (String) edges.get("id");
                         edge_source = (String) edges.get("source");
                         edge_target = (String) edges.get("target");
                    }
                    String type = (String) nodes.get("type");
                    JSONObject data = new JSONObject((Map) nodes.get("data"));
                    //JSONObject data = (JSONObject) nodes.get("data");
                    String label = (String) data.get("label");
                    JSONObject position = new JSONObject((Map) nodes.get("position"));

                    //JSONObject position = (JSONObject) nodes.get("position");
                    Number xNumber = (Number) position.getOrDefault("x", 0);
                    Number yNumber = (Number) position.getOrDefault("y", 0);

                    double x = xNumber.doubleValue();
                    double y = yNumber.doubleValue();


                    String dragHandle = (String) nodes.get("dragHandle");
                    String parentNode = (String) nodes.get("parentNode");

                    node_obj.setId(id);
                    node_obj.setType(type);
                    node_obj.setLabel(label);
                    node_obj.setX(x);
                    node_obj.setY(y);
                    node_obj.setDragHandle(dragHandle);
                    node_obj.setParentNode(parentNode);

                    if(temp) {
                        node_obj.setEdge_id(edge_id);
                        node_obj.setEdge_source(edge_source);
                        node_obj.setEdge_target(edge_target);
                    }
                    nodeService.create(node_obj);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    //String x = String.valueOf(json.get("id"));
        return new ResponseEntity<>(HttpStatus.CREATED);
    
    }
    @CrossOrigin
    @GetMapping("/get-node")
    public ResponseEntity<?> findAll(){
        String jsonString = "{\r\n    \"nodes\": [\r\n        {\r\n            \"id\": \"root\",\r\n            \"type\": \"mindmap\",\r\n            \"data\": {\r\n                \"label\": \"React Flow Mind Map\"\r\n            },\r\n            \"position\": {\r\n                \"x\": 0,\r\n                \"y\": 0\r\n            },\r\n            \"dragHandle\": \".dragHandle\",\r\n            \"width\": 194,\r\n            \"height\": 32\r\n        },\r\n        {\r\n            \"id\": \"isVUVyyx3DwjdXRebI710\",\r\n            \"type\": \"mindmap\",\r\n            \"data\": {\r\n                \"label\": \"New Node\"\r\n            },\r\n            \"position\": {\r\n                \"x\": -49.837443469940126,\r\n                \"y\": 55.595930067702724\r\n            },\r\n            \"dragHandle\": \".dragHandle\",\r\n            \"parentNode\": \"root\",\r\n            \"width\": 106,\r\n            \"height\": 32\r\n        },\r\n        {\r\n            \"id\": \"b0FoNWh9ppb6HScg4lxzs\",\r\n            \"type\": \"mindmap\",\r\n            \"data\": {\r\n                \"label\": \"New Node\"\r\n            },\r\n            \"position\": {\r\n                \"x\": -56.4070545802503,\r\n                \"y\": 68.32511306011972\r\n            },\r\n            \"dragHandle\": \".dragHandle\",\r\n            \"parentNode\": \"isVUVyyx3DwjdXRebI710\",\r\n            \"width\": 106,\r\n            \"height\": 32\r\n        }\r\n    ],\r\n    \"edges\": [\r\n        {\r\n            \"id\": \"nUx0jGeVbvVOU0ClAG2B4\",\r\n            \"source\": \"root\",\r\n            \"target\": \"isVUVyyx3DwjdXRebI710\"\r\n        },\r\n        {\r\n            \"id\": \"LtKgd6jxj9Kk-Qc91w-oO\",\r\n            \"source\": \"isVUVyyx3DwjdXRebI710\",\r\n            \"target\": \"b0FoNWh9ppb6HScg4lxzs\"\r\n        }\r\n    ]\r\n}";
        List<Node> nodes = nodeService.findAll();
        JSONObject json = new JSONObject();

        JSONArray nodesArray = new JSONArray();
        JSONArray edgesArray = new JSONArray();

        for (Node node : nodes) {
            JSONObject nodeObject = new JSONObject();
            nodeObject.put("id", node.getId());
            nodeObject.put("type", node.getType());
            nodeObject.put("dragHandle",node.getDragHandle());
            nodeObject.put("data", createDataObject(node.getLabel()));
            nodeObject.put("position", createPositionObject(node.getX(), node.getY()));


            // Set other node properties as needed
            nodesArray.add(nodeObject);

            if (node.getEdge_id() != null) {
                JSONObject edgeObject = new JSONObject();
                edgeObject.put("id", node.getId()); // Assuming the ID can be used as the edge ID
                edgeObject.put("source", node.getParentNode());
                edgeObject.put("target", node.getId());
                // Set other edge properties as needed
                edgesArray.add(edgeObject);
            }
        }

        json.put("nodes", nodesArray);
        json.put("edges", edgesArray);
        return new ResponseEntity<>(json.toString(), HttpStatus.OK);
    }
    private static JSONObject createDataObject(String label) {
        JSONObject dataObject = new JSONObject();
        dataObject.put("label", label);
        return dataObject;
    }

    private static JSONObject createPositionObject(double x, double y) {
        JSONObject positionObject = new JSONObject();
        positionObject.put("x", x);
        positionObject.put("y", y);
        return positionObject;
    }
    @CrossOrigin
    @GetMapping("/get-node/{id}")
    public ResponseEntity<?> findAll(@PathVariable Long id){

        return new ResponseEntity<>(nodeService.findNode(id), HttpStatus.OK);
    }
    @CrossOrigin
    @PutMapping("/get-node/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Node node){
        return new ResponseEntity<>(nodeService.update(id, node), HttpStatus.OK);
    }
    @CrossOrigin
    @DeleteMapping("/get-node/{id}")
    public ResponseEntity<?> deleteById(@PathVariable Long id){
        return new ResponseEntity<>(nodeService.delete(id), HttpStatus.OK);
    }



}
