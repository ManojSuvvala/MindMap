package com.example.SpringReact.service;

import com.example.SpringReact.domain.Node;
import com.example.SpringReact.domain.NodeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

//function, algorithm, transaction

@RequiredArgsConstructor
@Service
public class NodeService {

    private final NodeRepository nodeRepository;

    @Transactional
    public Node create(Node node){
        //nodeRepository.deleteAll();
        return nodeRepository.save(node);
    }

    /*
    public Book findBook(Long id){
        return bookRepository.findById(id).orElseThrow(new Supplier<IllegalArgumentException>() {
            @Override
            public IllegalArgumentException get() {
                return new IllegalArgumentException("Check Id");
            }
        });
    }
    */
    @Transactional(readOnly = true)
    public Node findNode(Long id){
        return nodeRepository.findById(id).orElseThrow(()->new IllegalArgumentException("Check Id"));
    }

    @Transactional(readOnly = true)
    public List<Node> findAll(){
        return nodeRepository.findAll();
    }

    @Transactional
    public Node update(Long id, Node node){
        Node nodeEntity = nodeRepository.findById(id)
                .orElseThrow(()->new IllegalArgumentException("check Id"));  //Persistence Context

        nodeEntity.setLabel(node.getLabel());
        nodeEntity.setParentNode(node.getParentNode());
        return nodeEntity;
    }// When the transaction end, the persisted data to the database update the database (flush)

    @Transactional
    public String delete(Long id){
        nodeRepository.deleteById(id);
        return "ok";
    }

}
