package com.example.SpringReact.service;

import com.example.SpringReact.domain.Node;
import com.example.SpringReact.domain.NodeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class NodeServiceTest {

    @Autowired
    NodeRepository nodeRepository;
    @Autowired
    NodeService nodeService;

    @Test
    void create() {
        //test case
        Node node = new Node();
        node.setData("Harry Potter");
        node.setData("J.K.Rolling");

        //run
        nodeService.create(node);

        System.out.println(node.getData());
        System.out.println(node.getId());

        Node result = nodeService.findNode(node.getId());
        assertEquals(node, result);
    }


    @Test
    void findBook() {
    }

    @Test
    void findAll() {
    }
}